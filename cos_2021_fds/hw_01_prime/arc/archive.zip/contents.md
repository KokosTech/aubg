# Contents of the HW1 assignment

- `sieve.cpp` - The main algorithm source code
- `timing_sieve.cpp` - The timing version of the original source code
- `counter_sieve.cpp` - The counter version of the original source code
- `doc.[md/pdf]` - Documentation of the whole process doing this HW1 assignmen
- `pseudo.txt` - An addition to the documentation - the thought process behind (2.)
